﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _12._11._19_MemoryGame_Itay
{
    public partial class Form1 : Form
    {

        private MemoryGame _currentGame;

        private Panel _pnlGameBoardContainer;
        public Form1()
        {
            InitializeComponent();
            initialiseSomeControls();
            initializeGameInThisForm();
            
        }
        private void initialiseSomeControls()
        {
            for (int i = 2; i <= 16; i *= 2) cmbBoardSize.Items.Add(i);
            cmbBoardSize.SelectedItem = 4;            
        }
       

        private void initializeGameInThisForm()
        {
            _currentGame = new MemoryGame((int)cmbBoardSize.SelectedItem);

            _pnlGameBoardContainer = new Panel();
            _pnlGameBoardContainer.Location = new Point(0, 0);
            _pnlGameBoardContainer.Width = _currentGame.BoardSize * new Label_field("?").Width + 40;
            _pnlGameBoardContainer.Height = _currentGame.BoardSize * new Label_field("?").Height + 40;
            this.Height = _pnlGameBoardContainer.Height + 100;
            this.Controls.Add(_pnlGameBoardContainer);

            lblIdentityRevealing.Location = new Point(_pnlGameBoardContainer.Location.X + 10, _pnlGameBoardContainer.Location.Y + _pnlGameBoardContainer.Height + 10);


            _currentGame.exportFieldsNow += new MemoryGame.exportFields((Label_field field) => { this._pnlGameBoardContainer.Controls.Add(field); });
            _currentGame.displayGame();

            _currentGame.yourScoreNow += (string score) => { lblYourScore.Text = $"Your score: {score}"; };
            _currentGame.opponentScoreNow += (string score) => { lblOpponentScore.Text = $"Opponent score: {score}"; };

            _currentGame.identityrevealingNow += (string idn) => { lblIdentityRevealing.Text = idn; };
        }

        private void btnNewGame_Click(object sender, EventArgs e)
        {
            //foreach (var s in this.Controls) { this.Controls.Remove(s as Label_field); }
            this.Controls.Remove(_pnlGameBoardContainer);
            lblYourScore.Text = "Your score: 0";
            lblOpponentScore.Text = "Opponent score: 0";
            initializeGameInThisForm();
            
            
        }

        private void lblYourScore_Click(object sender, EventArgs e)
        {

        }

        private void lblOpponentScore_Click(object sender, EventArgs e)
        {

        }
    }
}
