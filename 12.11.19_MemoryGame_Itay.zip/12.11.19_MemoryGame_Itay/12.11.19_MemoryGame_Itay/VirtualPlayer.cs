﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _12._11._19_MemoryGame_Itay
{
    class VirtualPlayer
    {
        public List<Label_field> _opponentFaults = new List<Label_field>();
        private List<Label_field> _possibilities = new List<Label_field>();
        public List<Label_field> _noPossibility = new List<Label_field>();
        private Random _rnd = new Random();
       

        
        private Label_field[,] _fieldsContainer;
        public VirtualPlayer(Label_field[,] fieldsContainer)
        {
            _fieldsContainer = fieldsContainer;
        }

        public void reformatOpponentfaults()
        {
            List<Label_field> reformatted = new List<Label_field>();
            foreach (var s in _opponentFaults) 
            {
                if (s.Used == false) reformatted.Add(s);
            }

            foreach(var s in _noPossibility)
            {
                if (reformatted.Contains(s)) reformatted.Remove(s);
            }


            _opponentFaults = reformatted;
        }

        public void possibilities()
        {
            _possibilities.Clear();
            foreach(var s in _fieldsContainer)
            {
                if (s.Used == false) 
                { 
                    _possibilities.Add(s);
                }
            }
        }

        private Label_field findMostPossibleToHit()
        {
            foreach(var s in _possibilities)
            {
                foreach(var ss in _opponentFaults)
                {
                    if (s.Equals(ss) && !_noPossibility.Contains(s)) { return s; }
                }
            }
            _noPossibility.Clear();
            return null;
        }

        private Label_field determineFieldToHitRandomly()
        {
            Label_field ret;
            do
            {
                ret = _possibilities[_rnd.Next(0, _possibilities.Count - 1)];
            }
            while (_noPossibility.Contains(ret));

            return ret;
        }

        public Label_field determineFieldToHit()
        {
            Label_field mostPossible = findMostPossibleToHit();

            

            if (mostPossible != null) return mostPossible;

            return determineFieldToHitRandomly();
        }









    }
}
